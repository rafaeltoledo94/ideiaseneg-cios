
  # Website for Business Consulting

  This is a code bundle for Website for Business Consulting. The original project is available at https://www.figma.com/design/hyZEZUdyXxD3LoxDNjuCPN/Website-for-Business-Consulting.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  