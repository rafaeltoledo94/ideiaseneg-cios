import React, { useState, useEffect } from 'react';
import { Navbar } from '@/app/components/Navbar';
import { Hero } from '@/app/components/Hero';
import { ConsultancySection } from '@/app/components/ConsultancySection';
import { NextLabSection } from '@/app/components/NextLabSection';
import { Footer } from '@/app/components/Footer';
import { Preloader } from '@/app/components/Preloader';
import { AnimatePresence } from 'motion/react';

function App() {
  const [loading, setLoading] = useState(true);

  return (
    <div className="min-h-screen bg-white">
      <AnimatePresence mode="wait">
        {loading && <Preloader onComplete={() => setLoading(false)} />}
      </AnimatePresence>

      {/* Main Content */}
      <div className={loading ? 'h-screen overflow-hidden' : ''}>
        <Navbar />
        <Hero />
        <ConsultancySection />
        <NextLabSection />
        <Footer />
      </div>
    </div>
  );
}

export default App;
